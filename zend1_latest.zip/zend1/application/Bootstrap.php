<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap {
    protected function _initLogger() {
        $this->bootstrap('log');

        $logger     = $this->getResource('log');
        Zend_Registry::set('logger', $logger);
    }

    protected function _initDB() {
        $dbConfig = new Zend_Config_Ini(APPLICATION_PATH . '/configs/db.ini', APPLICATION_ENV);
        $dbConfig = $dbConfig->resources->db;

        $dbAdapter = Zend_Db::factory($dbConfig->adapter, array(
            'host'      => $dbConfig->params->hostname,
            'username'  => $dbConfig->params->username,
            'password'  => $dbConfig->params->password,
            'dbname'    => $dbConfig->params->dbname,
            'driver_options' => array(
                PDO::MYSQL_ATTR_INIT_COMMAND => 'SET OPTION SQL_BIG_SELECTS = 1',
                PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8;'
            ),
        ));

        Zend_Db_Table_Abstract::setDefaultAdapter($dbAdapter);
        Zend_Registry::set('db', $dbAdapter);
    }

    protected function _initAutoload() {
        $autoloader = new Zend_Loader_Autoloader_Resource(array(
            'namespace' => '_',
            'basePath'  => APPLICATION_PATH,
        ));

        $autoloader->addResourceType('Controller', 'Controller', 'Controller');

        Zend_Loader_Autoloader::getInstance()->registerNamespace('Env_');

        return $autoloader;
    }

    protected function _initSiteRouters() {
        $appRoutes  = array();        

        foreach($appRoutes as $key => $router) {
            Zend_Controller_Front::getInstance()->getRouter()->addRoute($key, $router);
        }
    }
}