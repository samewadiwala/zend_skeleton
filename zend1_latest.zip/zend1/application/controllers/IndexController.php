<?php
	class IndexController extends Zend_Controller_Action
	{
		public function indexAction() {
			//echo 'I am ready.';die;
			//phpinfo();die;
		}
	}
?>