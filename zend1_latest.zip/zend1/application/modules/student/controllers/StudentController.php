<?php
	class Student_StudentController extends Zend_Controller_Action {
		private $studentModel = null;

		public function indexAction(){
			$this->_helper->layout->setLayout('layout');
			try{
				$students = $this->_getStudentModel()->getAllStudents();
				echo "<pre>";
				print_r($students);die;	
			} catch(Exception $e){
				echo $e->getMessage();
			}
			//$studentModel = new Student_Model_Student();
		}

		public function _getStudentModel(){
			if(is_null($this->studentModel)){
				$this->studentModel = new Student_Model_Student();
			}

			return $this->studentModel;
		}
	}