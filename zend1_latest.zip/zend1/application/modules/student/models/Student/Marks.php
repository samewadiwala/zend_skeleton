<?php 
	class Student_Model_Student_Marks extends Zend_Db_Table_Abstract
	{
		
		function __construct(argument)
		{
			# code...
		}
	}